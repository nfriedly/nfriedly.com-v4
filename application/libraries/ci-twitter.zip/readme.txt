/**
 * CodeIgniter Twitter API Library (http://www.haughin.com/code/twitter)
 * 
 * Author: Elliot Haughin (http://www.haughin.com), elliot@haughin.com
 *
 * ========================================================
 * REQUIRES: Connection Library (included)
 * ========================================================
 * 
 * VERSION: 2.2 (2009-03-07)
 * 
 **/